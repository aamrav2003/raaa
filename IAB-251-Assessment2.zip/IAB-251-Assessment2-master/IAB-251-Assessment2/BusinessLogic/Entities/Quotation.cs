﻿namespace IAB_251_Assessment2.BusinessLogic.Entities
{
    public class Quotation
    {
        public int Id { get; set; }
        public string clientName { get; set; }
        public DateTime dateIssued { get; set; }
        public string status { get; set; }
    }
}
