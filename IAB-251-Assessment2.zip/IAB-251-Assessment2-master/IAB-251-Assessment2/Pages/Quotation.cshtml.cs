using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using IAB_251_Assessment2.Application.Interfaces;
using IAB_251_Assessment2.BusinessLogic.Entities;
using IAB_251_Assessment2.Pages.ViewModels;
using IAB_251_Assessment2.Pages.User.Model;

namespace IAB_251_Assessment2.Pages
{
    public class QuotationModel : PageModel
    {
        private readonly IQuoteAppService _quoteAppService;
        public QuotationModel(IQuoteAppService quoteAppService)
        {
            _quoteAppService = quoteAppService;
        }
        [BindProperty]
        public QuoteViewModel Quote { get; set; }
        public List<QuoteViewModel> QuoteList { get; set; } = new();
        public void OnGet()
        {
            var quotes = _quoteAppService.GetAllQuotes();

            QuoteList = quotes.Select(q => new QuoteViewModel
            {
                clientName = q.clientName,
                dateIssued = q.dateIssued,
                status = q.status
            }).ToList();
        }
        public IActionResult OnPost()
        {
            var _dateIssued = DateTime.Now;
            if (!ModelState.IsValid)
                return Page();

            _quoteAppService.AddQuote(new BusinessLogic.Entities.Quotation
            {
                clientName = Quote.clientName,
                dateIssued = _dateIssued,
                status = Quote.status
            });

            return RedirectToPage("/Quotation"); ;
        }
    }
}
