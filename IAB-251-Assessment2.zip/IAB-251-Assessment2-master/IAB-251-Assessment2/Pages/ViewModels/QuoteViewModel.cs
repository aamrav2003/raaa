﻿namespace IAB_251_Assessment2.Pages.ViewModels
{
    public class QuoteViewModel
    {
        public int Id { get; set; }
        public string clientName { get; set; }
        public DateTime dateIssued { get; set; }
        public string status { get; set; }
    }
}
