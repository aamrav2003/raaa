using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IAB_251_Assessment2.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
