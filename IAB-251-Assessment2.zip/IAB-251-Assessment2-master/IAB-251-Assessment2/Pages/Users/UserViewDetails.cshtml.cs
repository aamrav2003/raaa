using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IAB_251_Assessment2.Pages.Users
{
    public class UserViewDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
