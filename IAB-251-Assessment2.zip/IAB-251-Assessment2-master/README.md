#Run your VS project and go to the main screen of your application (User story T1) 
#Sign up /Register a new customer (User story T2) 
#Login as the new customer (User story I1)
#Start a new quotation request for that customer and submit the quotation request (User Story I2)
$Log out from the customer (User Story T4)
#Register/Sign-up a new employee (User Story T3)
#Login as the new employee (User Story I3)
#Now employee should see the quotation request sent by the customer. (User Story I3)
#Employee can accept the quotation request and then start preparing the quotation. (User Story I3)
#Show how you are preparing the quotation by using the Rate schedule and show the functionality of discount function as well.  (User Story I4, User Story I5)
#Employee will submit the quotation (User Story I5)
#Log out from the Employee and login as the Customer again. 
#Now customer should be able to view the quotation sent by the employee. (User Story I6)
#Customer can accept or reject the quotation (User Story I6)
#Now you can login as the employee again and show the quotations with their status (Accept/Reject/Pending) – (User story T5)
 

#In addition to demonstrating the core features of your application, you are encouraged to include:

#A brief walkthrough of your test cases (Task 3) to show how you validated the system.

#Highlights of your Agile development process (Task 1), including sprint planning or backlog management.

